async function loadData(){

    console.log("loadData 실행");

    const response = await fetch("/average");

    const data = await response.json();

    console.log(data);


    document.getElementById("temper").innerHTML =
        data.temperature + " ℃";


    document.getElementById("humid").innerHTML =
        data.humidity + " %";

}


loadData();